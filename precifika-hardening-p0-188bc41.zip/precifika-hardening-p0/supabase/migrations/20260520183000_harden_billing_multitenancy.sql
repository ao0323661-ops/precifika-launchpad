-- Harden billing data integrity, subscription status values, and trial onboarding.

-- Normalize existing rows before tightening constraints.
UPDATE public.subscriptions
SET status = CASE status
  WHEN 'pending' THEN 'past_due'
  WHEN 'inactive' THEN 'unpaid'
  WHEN 'expired' THEN 'unpaid'
  ELSE status
END
WHERE status IN ('pending', 'inactive', 'expired');

ALTER TABLE public.subscriptions
DROP CONSTRAINT IF EXISTS subscriptions_status_check;

ALTER TABLE public.subscriptions
ADD CONSTRAINT subscriptions_status_check
CHECK (status IN ('active', 'past_due', 'canceled', 'unpaid'));

ALTER TABLE public.saas_subscriptions
DROP CONSTRAINT IF EXISTS saas_subscriptions_status_check;

ALTER TABLE public.saas_subscriptions
ADD CONSTRAINT saas_subscriptions_status_check
CHECK (status IN ('active', 'trial', 'expired', 'canceled', 'past_due', 'unpaid'));

ALTER TABLE public.saas_subscriptions
DROP CONSTRAINT IF EXISTS saas_subscriptions_plan_name_check;

ALTER TABLE public.saas_subscriptions
ADD CONSTRAINT saas_subscriptions_plan_name_check
CHECK (plan_name IN ('starter', 'pro', 'premium', 'trial'));

-- Idempotency and upsert targets used by webhooks.
ALTER TABLE public.customers
DROP CONSTRAINT IF EXISTS customers_user_id_email_key;

ALTER TABLE public.customers
ADD CONSTRAINT customers_user_id_email_key UNIQUE (user_id, email);

ALTER TABLE public.subscriptions
DROP CONSTRAINT IF EXISTS subscriptions_external_subscription_id_key;

ALTER TABLE public.subscriptions
ADD CONSTRAINT subscriptions_external_subscription_id_key UNIQUE (external_subscription_id);

ALTER TABLE public.payments
DROP CONSTRAINT IF EXISTS payments_external_payment_id_key;

ALTER TABLE public.payments
ADD CONSTRAINT payments_external_payment_id_key UNIQUE (external_payment_id);

ALTER TABLE public.webhook_logs
DROP CONSTRAINT IF EXISTS webhook_logs_gateway_event_id_key;

ALTER TABLE public.webhook_logs
ADD CONSTRAINT webhook_logs_gateway_event_id_key UNIQUE (gateway_provider, event_id);

CREATE INDEX IF NOT EXISTS idx_payments_user_created_at
ON public.payments(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_subscriptions_user_status
ON public.subscriptions(user_id, status);

CREATE INDEX IF NOT EXISTS idx_customers_user_email
ON public.customers(user_id, email);

-- Keep SaaS subscription timestamps current.
DROP TRIGGER IF EXISTS update_saas_subscriptions_updated_at ON public.saas_subscriptions;

CREATE TRIGGER update_saas_subscriptions_updated_at
BEFORE UPDATE ON public.saas_subscriptions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Cross-tenant relationship guard. RLS protects API reads/writes; these triggers
-- also prevent service-role bugs from linking one tenant's customer/subscription
-- to another tenant's payment record.
CREATE OR REPLACE FUNCTION public.ensure_billing_customer_belongs_to_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.customer_id IS NOT NULL AND NOT EXISTS (
    SELECT 1
    FROM public.customers
    WHERE id = NEW.customer_id
      AND user_id = NEW.user_id
  ) THEN
    RAISE EXCEPTION 'customer_id does not belong to user_id';
  END IF;

  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.ensure_payment_subscription_belongs_to_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.subscription_id IS NOT NULL AND NOT EXISTS (
    SELECT 1
    FROM public.subscriptions
    WHERE id = NEW.subscription_id
      AND user_id = NEW.user_id
  ) THEN
    RAISE EXCEPTION 'subscription_id does not belong to user_id';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS ensure_subscriptions_customer_tenant ON public.subscriptions;

CREATE TRIGGER ensure_subscriptions_customer_tenant
BEFORE INSERT OR UPDATE OF user_id, customer_id ON public.subscriptions
FOR EACH ROW
EXECUTE FUNCTION public.ensure_billing_customer_belongs_to_user();

DROP TRIGGER IF EXISTS ensure_payments_customer_tenant ON public.payments;

CREATE TRIGGER ensure_payments_customer_tenant
BEFORE INSERT OR UPDATE OF user_id, customer_id ON public.payments
FOR EACH ROW
EXECUTE FUNCTION public.ensure_billing_customer_belongs_to_user();

DROP TRIGGER IF EXISTS ensure_payments_subscription_tenant ON public.payments;

CREATE TRIGGER ensure_payments_subscription_tenant
BEFORE INSERT OR UPDATE OF user_id, subscription_id ON public.payments
FOR EACH ROW
EXECUTE FUNCTION public.ensure_payment_subscription_belongs_to_user();

-- Create profile and a real seven-day trial for every new account.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'name', split_part(NEW.email, '@', 1))
  )
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO public.saas_subscriptions (
    user_id,
    plan_name,
    status,
    started_at,
    expires_at
  )
  VALUES (
    NEW.id,
    'trial',
    'trial',
    now(),
    now() + INTERVAL '7 days'
  )
  ON CONFLICT (user_id) DO NOTHING;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW
EXECUTE FUNCTION public.handle_new_user();

-- Backfill trial rows for already-created users that do not have a SaaS plan.
INSERT INTO public.saas_subscriptions (
  user_id,
  plan_name,
  status,
  started_at,
  expires_at
)
SELECT
  users.id,
  'trial',
  'trial',
  now(),
  now() + INTERVAL '7 days'
FROM auth.users
WHERE NOT EXISTS (
  SELECT 1
  FROM public.saas_subscriptions
  WHERE saas_subscriptions.user_id = users.id
);
