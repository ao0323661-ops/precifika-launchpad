import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

type JsonRecord = Record<string, unknown>;
type PlanId = "starter" | "pro" | "premium" | "trial";
type SaasStatus = "active" | "trial" | "expired" | "canceled" | "past_due" | "unpaid";

type WebhookLog = {
  id: string;
  status: string | null;
};

const GATEWAY_PROVIDER = "abacatepay";
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function requiredEnv(name: string): string {
  const value = Deno.env.get(name);
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function asRecord(value: unknown): JsonRecord | undefined {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as JsonRecord)
    : undefined;
}

function asString(value: unknown): string | undefined {
  return typeof value === "string" && value.length > 0 ? value : undefined;
}

function decodeBase64(value: string): Uint8Array | null {
  try {
    const binary = atob(value);
    return Uint8Array.from(binary, (char) => char.charCodeAt(0));
  } catch {
    return null;
  }
}

function timingSafeEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;

  let diff = 0;
  for (let i = 0; i < a.length; i += 1) {
    diff |= a[i] ^ b[i];
  }

  return diff === 0;
}

async function verifySignature(
  rawBody: string,
  signature: string,
  publicKey: string,
): Promise<boolean> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(publicKey),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );

  const expected = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(rawBody));
  const expectedBase64 = btoa(String.fromCharCode(...new Uint8Array(expected)));
  const expectedBytes = decodeBase64(expectedBase64);
  const receivedBytes = decodeBase64(signature);

  return Boolean(expectedBytes && receivedBytes && timingSafeEqual(expectedBytes, receivedBytes));
}

function readNestedString(record: JsonRecord | undefined, path: string[]): string | undefined {
  let current: unknown = record;

  for (const key of path) {
    const nested = asRecord(current);
    if (!nested) return undefined;
    current = nested[key];
  }

  return asString(current);
}

function findMetadata(payload: JsonRecord): JsonRecord | undefined {
  const data = asRecord(payload.data);
  return (
    asRecord(payload.metadata) ??
    asRecord(data?.metadata) ??
    asRecord(asRecord(data?.checkout)?.metadata) ??
    asRecord(asRecord(data?.subscription)?.metadata)
  );
}

function normalizePlanId(value: unknown): PlanId | undefined {
  if (value === "starter" || value === "pro" || value === "premium" || value === "trial") {
    return value;
  }
  return undefined;
}

function extractUserId(payload: JsonRecord): string | undefined {
  const data = asRecord(payload.data);
  const metadata = findMetadata(payload);
  const externalId =
    readNestedString(data, ["checkout", "externalId"]) ??
    readNestedString(data, ["subscription", "externalId"]) ??
    asString(data?.externalId);

  const metadataUserId = asString(metadata?.userId);
  if (metadataUserId) return metadataUserId;

  const externalIdParts = externalId?.split(":") ?? [];
  const possibleUuid = externalIdParts.find((part) => UUID_PATTERN.test(part));
  return possibleUuid;
}

function extractPlanId(payload: JsonRecord): PlanId | undefined {
  const metadata = findMetadata(payload);
  return normalizePlanId(metadata?.planId);
}

function extractGatewayId(payload: JsonRecord): string | null {
  const data = asRecord(payload.data);
  return (
    readNestedString(data, ["subscription", "id"]) ??
    readNestedString(data, ["checkout", "id"]) ??
    asString(data?.id) ??
    asString(payload.id) ??
    null
  );
}

function extractExpiration(payload: JsonRecord): string {
  const data = asRecord(payload.data);
  const date =
    readNestedString(data, ["subscription", "nextBillingAt"]) ??
    readNestedString(data, ["subscription", "expiresAt"]) ??
    readNestedString(data, ["checkout", "nextBillingAt"]) ??
    readNestedString(data, ["checkout", "expiresAt"]) ??
    asString(data?.nextBillingAt) ??
    asString(data?.expiresAt);

  if (date) return date;

  const fallback = new Date();
  fallback.setMonth(fallback.getMonth() + 1);
  return fallback.toISOString();
}

function statusForEvent(event: string): SaasStatus | undefined {
  if (event === "checkout.completed") return "active";
  if (event === "subscription.completed") return "active";
  if (event === "subscription.renewed") return "active";
  if (event === "subscription.cancelled" || event === "subscription.canceled") {
    return "canceled";
  }
  if (event === "checkout.refunded" || event === "subscription.refunded") {
    return "unpaid";
  }
  if (event === "checkout.disputed" || event === "subscription.disputed") {
    return "past_due";
  }
  return undefined;
}

async function getOrCreateLog(
  supabase: ReturnType<typeof createClient>,
  payload: JsonRecord,
): Promise<WebhookLog> {
  const eventId = asString(payload.id);
  const eventType = asString(payload.event);

  if (!eventId || !eventType) {
    throw new Error("Webhook payload missing id or event");
  }

  const { data: existing, error: existingError } = await supabase
    .from("webhook_logs")
    .select("id,status")
    .eq("gateway_provider", GATEWAY_PROVIDER)
    .eq("event_id", eventId)
    .maybeSingle();

  if (existingError) throw existingError;

  if (existing) {
    return existing as WebhookLog;
  }

  const { data: inserted, error: insertError } = await supabase
    .from("webhook_logs")
    .insert({
      event_id: eventId,
      event_type: eventType,
      payload,
      gateway_provider: GATEWAY_PROVIDER,
      status: "pending",
    })
    .select("id,status")
    .single();

  if (insertError) throw insertError;
  return inserted as WebhookLog;
}

async function markLog(
  supabase: ReturnType<typeof createClient>,
  logId: string,
  fields: JsonRecord,
) {
  const { error } = await supabase.from("webhook_logs").update(fields).eq("id", logId);
  if (error) console.error("[Webhook] failed to update log", error);
}

serve(async (req) => {
  if (req.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }

  let supabase: ReturnType<typeof createClient> | undefined;
  let logEntry: WebhookLog | undefined;

  try {
    const webhookSecret = requiredEnv("ABACATEPAY_WEBHOOK_SECRET");
    const publicKey = requiredEnv("ABACATEPAY_PUBLIC_KEY");
    const supabaseUrl = requiredEnv("SUPABASE_URL");
    const serviceRoleKey = requiredEnv("SUPABASE_SERVICE_ROLE_KEY");
    const url = new URL(req.url);
    const secretParam = url.searchParams.get("webhookSecret");
    const signature = req.headers.get("X-Webhook-Signature");

    if (secretParam !== webhookSecret) {
      return jsonResponse({ error: "Unauthorized" }, 401);
    }

    if (!signature) {
      return jsonResponse({ error: "Missing webhook signature" }, 401);
    }

    const rawBody = await req.text();
    const isValidSignature = await verifySignature(rawBody, signature, publicKey);

    if (!isValidSignature) {
      return jsonResponse({ error: "Invalid webhook signature" }, 401);
    }

    const payload = asRecord(JSON.parse(rawBody));
    if (!payload) {
      return jsonResponse({ error: "Invalid JSON payload" }, 400);
    }

    supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    });

    logEntry = await getOrCreateLog(supabase, payload);

    if (logEntry.status === "processed") {
      return jsonResponse({ message: "Already processed" });
    }

    await markLog(supabase, logEntry.id, {
      status: "pending",
      error_message: null,
      payload,
    });

    const event = asString(payload.event) ?? "";
    const targetStatus = statusForEvent(event);
    const userId = extractUserId(payload);
    const planId = extractPlanId(payload);

    if (!targetStatus) {
      await markLog(supabase, logEntry.id, {
        status: "processed",
        processed_at: new Date().toISOString(),
      });
      return jsonResponse({ success: true, ignored: true });
    }

    if (!userId || !UUID_PATTERN.test(userId)) {
      await markLog(supabase, logEntry.id, {
        status: "error",
        error_message: "Valid user context not found",
      });
      return jsonResponse({ error: "User context not found" });
    }

    if (!planId || planId === "trial") {
      await markLog(supabase, logEntry.id, {
        user_id: userId,
        status: "error",
        error_message: "Valid plan metadata not found",
      });
      return jsonResponse({ error: "Plan context not found" });
    }

    const expiresAt =
      targetStatus === "canceled" || targetStatus === "unpaid"
        ? new Date().toISOString()
        : extractExpiration(payload);

    const { error: subscriptionError } = await supabase.from("saas_subscriptions").upsert(
      {
        user_id: userId,
        plan_name: planId,
        status: targetStatus,
        external_subscription_id: extractGatewayId(payload),
        gateway_provider: GATEWAY_PROVIDER,
        expires_at: expiresAt,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "user_id" },
    );

    if (subscriptionError) throw subscriptionError;

    await markLog(supabase, logEntry.id, {
      user_id: userId,
      status: "processed",
      processed_at: new Date().toISOString(),
    });

    return jsonResponse({ success: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error("[Webhook] processing error", message);

    if (supabase && logEntry) {
      await markLog(supabase, logEntry.id, {
        status: "error",
        error_message: message,
      });
    }

    return jsonResponse({ error: "Webhook processing failed" }, 500);
  }
});
