import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

type PlanId = "starter" | "pro" | "premium";

type CheckoutRequest = {
  planId?: string;
};

type AbacateCheckoutResponse = {
  success?: boolean;
  error?: string | null;
  data?: {
    id?: string;
    url?: string;
  };
};

const PLAN_PRODUCT_ENV: Record<PlanId, string> = {
  starter: "ABACATEPAY_STARTER_PRODUCT_ID",
  pro: "ABACATEPAY_PRO_PRODUCT_ID",
  premium: "ABACATEPAY_PREMIUM_PRODUCT_ID",
};

function requiredEnv(name: string): string {
  const value = Deno.env.get(name);
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

function corsHeaders(req: Request): HeadersInit {
  const origin = req.headers.get("origin") ?? "*";
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    Vary: "Origin",
  };
}

function jsonResponse(req: Request, body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders(req), "Content-Type": "application/json" },
  });
}

function isPlanId(planId: string | undefined): planId is PlanId {
  return planId === "starter" || planId === "pro" || planId === "premium";
}

function getPublicBaseUrl(req: Request): string {
  const configuredUrl = Deno.env.get("APP_PUBLIC_URL");
  const origin = req.headers.get("origin");
  const baseUrl = configuredUrl || origin;

  if (!baseUrl || !/^https?:\/\//.test(baseUrl)) {
    throw new Error("Missing valid APP_PUBLIC_URL or request origin");
  }

  return baseUrl.replace(/\/$/, "");
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders(req) });
  }

  if (req.method !== "POST") {
    return jsonResponse(req, { error: "Method not allowed" }, 405);
  }

  try {
    const supabaseUrl = requiredEnv("SUPABASE_URL");
    const supabaseAnonKey = requiredEnv("SUPABASE_ANON_KEY");
    const abacateApiKey = requiredEnv("ABACATEPAY_API_KEY");
    const authorization = req.headers.get("Authorization");

    if (!authorization?.startsWith("Bearer ")) {
      return jsonResponse(req, { error: "Unauthorized" }, 401);
    }

    const supabaseClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authorization } },
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    });

    const {
      data: { user },
      error: userError,
    } = await supabaseClient.auth.getUser();

    if (userError || !user) {
      return jsonResponse(req, { error: "Unauthorized" }, 401);
    }

    const payload = (await req.json()) as CheckoutRequest;
    if (!isPlanId(payload.planId)) {
      return jsonResponse(req, { error: "Invalid plan" }, 400);
    }

    const productId = requiredEnv(PLAN_PRODUCT_ENV[payload.planId]);
    const baseUrl = getPublicBaseUrl(req);

    const response = await fetch("https://api.abacatepay.com/v2/subscriptions/create", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${abacateApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        items: [{ id: productId, quantity: 1 }],
        methods: ["CARD"],
        returnUrl: `${baseUrl}/dashboard/pricing`,
        completionUrl: `${baseUrl}/dashboard?success=true`,
        externalId: `precifika:${user.id}:${payload.planId}:${crypto.randomUUID()}`,
        metadata: {
          source: "precifika",
          userId: user.id,
          planId: payload.planId,
        },
      }),
    });

    const result = (await response.json()) as AbacateCheckoutResponse;

    if (!response.ok || !result.success || !result.data?.url) {
      console.error("[AbacatePay] checkout creation failed", result);
      return jsonResponse(req, { error: "Failed to create checkout" }, 502);
    }

    return jsonResponse(req, {
      url: result.data.url,
      checkoutId: result.data.id,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error("[Checkout] unexpected error", message);
    return jsonResponse(req, { error: "Unexpected checkout error" }, 500);
  }
});
